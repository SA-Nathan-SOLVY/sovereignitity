# Huginn for SOVEREIGNITITY™

Self-hosted automation platform for enrollment management.

## Quick Start

1. Install Docker Desktop for Mac M1
2. Run: `docker-compose up -d`
3. Access: http://localhost:3000
4. Login: admin / password

See HUGINN_MAC_M1_SETUP.md for complete instructions.
