# 🤖 Huginn Setup for Mac M1 - SOVEREIGNITITY™ Edition

## Complete Self-Hosted Automation Platform

**Huginn** is your sovereignty-aligned automation platform - self-hosted, open-source, and completely under your control.

---

## ✅ What is Huginn?

**Huginn** = Self-hosted Zapier/IFTTT alternative

**Perfect for SOVEREIGNITITY™ because:**
- ✅ **Self-hosted** - Your infrastructure, your control
- ✅ **Open source** - No vendor lock-in
- ✅ **Free forever** - No subscription costs
- ✅ **Privacy-first** - Your data never leaves your server
- ✅ **Powerful** - Handles complex automation workflows
- ✅ **Web-based** - Beautiful UI, easy to use

---

## 🚀 Quick Install (Mac M1) - 10 Minutes

### Prerequisites

**1. Install Docker Desktop for Mac (M1/ARM)**

```bash
# Download from: https://www.docker.com/products/docker-desktop/
# Or install via Homebrew:
brew install --cask docker
```

**2. Start Docker Desktop**
- Open Docker Desktop app
- Wait for it to start (whale icon in menu bar)

### Installation Steps

**Step 1: Create Huginn Directory**

```bash
# Create directory structure
mkdir -p ~/huginn/{data,logs}
cd ~/huginn
```

**Step 2: Create Docker Compose File**

```bash
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  huginn-db:
    image: mysql:8.0
    platform: linux/arm64
    container_name: huginn-db
    environment:
      MYSQL_ROOT_PASSWORD: sovereignitity2025
      MYSQL_DATABASE: huginn_production
      MYSQL_USER: huginn
      MYSQL_PASSWORD: huginn2025
    volumes:
      - ./data/mysql:/var/lib/mysql
    restart: unless-stopped
    networks:
      - huginn-network

  huginn:
    image: huginn/huginn
    platform: linux/arm64
    container_name: huginn
    depends_on:
      - huginn-db
    ports:
      - "3000:3000"
    environment:
      # Database Configuration
      - DATABASE_ADAPTER=mysql2
      - DATABASE_ENCODING=utf8mb4
      - DATABASE_RECONNECT=true
      - DATABASE_NAME=huginn_production
      - DATABASE_POOL=20
      - DATABASE_USERNAME=huginn
      - DATABASE_PASSWORD=huginn2025
      - DATABASE_HOST=huginn-db
      - DATABASE_PORT=3306
      
      # Application Configuration
      - APP_SECRET_TOKEN=sovereignitity_huginn_secret_token_2025_secure
      - INVITATION_CODE=SOLVY2026
      - REQUIRE_CONFIRMED_EMAIL=false
      - SKIP_INVITATION_CODE=false
      
      # Email Configuration (optional - for notifications)
      - SMTP_DOMAIN=localhost
      - SMTP_USER_NAME=
      - SMTP_PASSWORD=
      - SMTP_SERVER=
      - SMTP_PORT=587
      - SMTP_AUTHENTICATION=plain
      - SMTP_ENABLE_STARTTLS_AUTO=true
      
      # Timezone
      - TIMEZONE=America/Chicago
      
    volumes:
      - ./data/huginn:/var/lib/huginn
      - ./logs:/app/log
    restart: unless-stopped
    networks:
      - huginn-network

networks:
  huginn-network:
    driver: bridge
EOF
```

**Step 3: Create Environment File**

```bash
cat > .env << 'EOF'
# Huginn Configuration for SOVEREIGNITITY™
INVITATION_CODE=SOLVY2026
DATABASE_PASSWORD=huginn2025
MYSQL_ROOT_PASSWORD=sovereignitity2025
APP_SECRET_TOKEN=sovereignitity_huginn_secret_token_2025_secure
EOF
```

**Step 4: Start Huginn**

```bash
# Pull images and start containers
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f huginn
```

**Step 5: Wait for Initialization (2-3 minutes)**

```bash
# Watch the logs until you see:
# "Puma starting in single mode..."
# "* Listening on http://0.0.0.0:3000"

# Press Ctrl+C to stop watching logs
```

**Step 6: Access Huginn**

Open browser: **http://localhost:3000**

**Default Login:**
- **Username:** `admin`
- **Password:** `password`

**⚠️ IMPORTANT:** Change the password immediately after first login!

---

## 🔐 First-Time Setup

### 1. Login
- Go to http://localhost:3000
- Username: `admin`
- Password: `password`

### 2. Change Password
- Click your username (top right)
- Click "Account Settings"
- Change password to something secure
- Save

### 3. Create Enrollment Webhook Agent

**Click "Agents" → "New Agent"**

**Agent Type:** Webhook Agent

**Name:** SOVEREIGNITITY Enrollment Webhook

**Options:**
```json
{
  "secret": "SOLVY2026_enrollment_secret",
  "expected_receive_period_in_days": "365",
  "payload_path": "."
}
```

**Save Agent**

**Get Webhook URL:**
- Click on the agent
- Copy the webhook URL (looks like: `http://localhost:3000/users/1/web_requests/1/SOLVY2026_enrollment_secret`)

### 4. Create Google Sheets Agent

**Click "Agents" → "New Agent"**

**Agent Type:** Data Output Agent

**Name:** Save to Google Sheets

**Options:**
```json
{
  "secrets": ["GOOGLE_SHEETS_API_KEY"],
  "mode": "append",
  "expected_receive_period_in_days": "2"
}
```

**Connect:** Link this agent to receive events from the Webhook Agent

---

## 🔗 Connecting to Your Website

### Update EnrollmentForm.jsx

Replace the fetch URL with your Huginn webhook:

```javascript
// In /home/ubuntu/sovereignitity-platform/src/components/EnrollmentForm.jsx

const response = await fetch('http://localhost:3000/users/1/web_requests/1/SOLVY2026_enrollment_secret', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify(enrollmentData)
})
```

---

## 📊 Creating Automation Workflows

### Example: Enrollment → Google Sheets → Email

**1. Webhook Agent** (receives enrollment)
↓
**2. Data Transform Agent** (format data)
↓
**3. Google Sheets Agent** (save to sheet)
↓
**4. Email Agent** (send confirmation)

### Creating Each Agent:

**Webhook Agent:** (Already created above)

**Data Transform Agent:**
```json
{
  "mode": "clean",
  "matchers": [
    {
      "path": "fullName",
      "to": "name"
    },
    {
      "path": "email",
      "to": "email"
    }
  ],
  "expected_receive_period_in_days": "2"
}
```

**Email Agent:**
```json
{
  "subject": "Welcome to SOVEREIGNITITY™!",
  "body": "Hi {{name}},\n\nThank you for enrolling!\n\nYour journey to economic sovereignty begins now.",
  "recipients": ["{{email}}"],
  "expected_receive_period_in_days": "2"
}
```

---

## 🛠️ Useful Commands

### Start Huginn
```bash
cd ~/huginn
docker-compose up -d
```

### Stop Huginn
```bash
cd ~/huginn
docker-compose stop
```

### Restart Huginn
```bash
cd ~/huginn
docker-compose restart
```

### View Logs
```bash
cd ~/huginn
docker-compose logs -f huginn
```

### Update Huginn
```bash
cd ~/huginn
docker-compose pull
docker-compose up -d
```

### Backup Data
```bash
cd ~/huginn
tar -czf huginn-backup-$(date +%Y%m%d).tar.gz data/
```

### Restore Data
```bash
cd ~/huginn
docker-compose stop
tar -xzf huginn-backup-YYYYMMDD.tar.gz
docker-compose up -d
```

---

## 🌐 Exposing Huginn to the Internet

### Option 1: ngrok (Quick Testing)

```bash
# Install ngrok
brew install ngrok

# Expose Huginn
ngrok http 3000
```

Your webhook URL becomes:
```
https://abc123.ngrok.io/users/1/web_requests/1/SOLVY2026_enrollment_secret
```

### Option 2: Cloudflare Tunnel (Permanent)

```bash
# Install cloudflared
brew install cloudflare/cloudflare/cloudflared

# Login
cloudflared tunnel login

# Create tunnel
cloudflared tunnel create sovereignitity-huginn

# Configure tunnel
cat > ~/.cloudflared/config.yml << 'EOF'
tunnel: sovereignitity-huginn
credentials-file: /Users/YOUR_USERNAME/.cloudflared/TUNNEL_ID.json

ingress:
  - hostname: huginn.yourdomain.com
    service: http://localhost:3000
  - service: http_status:404
EOF

# Run tunnel
cloudflared tunnel run sovereignitity-huginn
```

### Option 3: Deploy to Ubuntu Server

Copy the `docker-compose.yml` to your Ubuntu server and run there.

---

## 🔐 Security Best Practices

### 1. Change Default Passwords
```bash
# Edit docker-compose.yml
# Change these values:
- MYSQL_ROOT_PASSWORD=your_secure_password_here
- MYSQL_PASSWORD=your_secure_password_here
- APP_SECRET_TOKEN=your_long_random_token_here
```

### 2. Use Strong Invitation Code
```bash
# Edit docker-compose.yml
- INVITATION_CODE=your_complex_invitation_code
```

### 3. Enable HTTPS
Use Cloudflare Tunnel or reverse proxy (nginx) with SSL certificate.

### 4. Firewall Rules
```bash
# Only allow localhost access
# Use tunnel or VPN for remote access
```

### 5. Regular Backups
```bash
# Add to crontab
0 2 * * * cd ~/huginn && tar -czf ~/backups/huginn-$(date +\%Y\%m\%d).tar.gz data/
```

---

## 📈 Monitoring & Maintenance

### Check Container Health
```bash
docker-compose ps
```

### View Resource Usage
```bash
docker stats huginn huginn-db
```

### Database Size
```bash
docker exec huginn-db mysql -u root -psoverignitity2025 -e "SELECT table_schema AS 'Database', ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size (MB)' FROM information_schema.tables WHERE table_schema='huginn_production' GROUP BY table_schema;"
```

### Clean Up Old Events
In Huginn UI:
- Go to "Scenarios"
- Create cleanup scenario
- Schedule to run weekly

---

## 🎯 SOVEREIGNITITY™ Integration

### Enrollment Workflow

**1. Website Form Submission**
```
[EnrollmentForm.jsx] → POST → [Huginn Webhook]
```

**2. Huginn Processing**
```
[Webhook Agent] → [Transform Agent] → [Google Sheets Agent] → [Email Agent]
```

**3. Data Storage**
```
[Google Sheets] ← Enrollment Data
[Admin Dashboard] ← Stats via API
```

### IBC Policy Loan Workflow

**1. Member Submits IBC Request**
```
[Website Form] → [Huginn Webhook]
```

**2. Huginn Automation**
```
[Webhook] → [Generate OneAmerica Form] → [Email to Admin] → [Update Database]
```

**3. Admin Action**
```
[Review Request] → [Sign Form] → [Submit to OneAmerica]
```

---

## 🆚 Huginn vs Node-RED

| Feature | Huginn | Node-RED |
|---------|--------|----------|
| **Interface** | Web-based, user-friendly | Visual flow editor |
| **Learning Curve** | Easy | Moderate |
| **Scheduling** | Built-in cron | Requires nodes |
| **Data Storage** | Built-in database | External required |
| **Email** | Built-in | Requires nodes |
| **API Calls** | Easy | Easy |
| **Scenarios** | Built-in | Manual grouping |
| **Best For** | Non-technical users | Technical users |

**Recommendation:** Use **both**!
- **Huginn** for enrollment, notifications, scheduled tasks
- **Node-RED** for complex data processing, real-time dashboards

---

## 🎉 You're Ready!

**Huginn is now running on your Mac M1!**

**Access:** http://localhost:3000  
**Username:** admin  
**Password:** password (change immediately!)

**Next Steps:**
1. Change admin password
2. Create enrollment webhook
3. Connect to your website
4. Test enrollment flow
5. Set up email notifications

---

## 📞 Quick Reference

### URLs
- **Huginn UI:** http://localhost:3000
- **Webhook Endpoint:** http://localhost:3000/users/1/web_requests/1/YOUR_SECRET

### Credentials
- **Admin Username:** admin
- **Admin Password:** password (CHANGE THIS!)
- **Invitation Code:** SOLVY2026
- **Database Password:** huginn2025

### Directories
- **Config:** ~/huginn/docker-compose.yml
- **Data:** ~/huginn/data/
- **Logs:** ~/huginn/logs/

### Commands
- **Start:** `cd ~/huginn && docker-compose up -d`
- **Stop:** `cd ~/huginn && docker-compose stop`
- **Logs:** `cd ~/huginn && docker-compose logs -f`
- **Restart:** `cd ~/huginn && docker-compose restart`

---

*"Your automation, your infrastructure, your sovereignty."* 🤖🦅

**Huginn + SOVEREIGNITITY™ = Complete Automation Freedom!** 🚀

